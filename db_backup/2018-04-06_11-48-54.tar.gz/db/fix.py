import timestring
from pytz import timezone
import sys
import time
from datetime import datetime
from tinydb import TinyDB, Query, where

from functools import partial


KR = timezone('Asia/Seoul')

print ("Fix")
db = TinyDB('db.json')
tbl = db.table('reports')
qry = Query()
start_date = "24 Feb 2018"
end_date = "24 Feb 2018"

start = KR.localize(datetime.strptime(start_date, '%d %b %Y').replace(hour=0, minute=0, second=0))

end = KR.localize(datetime.strptime(end_date, '%d %b %Y').replace(hour=23, minute=59, second=59))


"""
result = tbl.search((str(qry.report_time) >= str(start.timestamp())) &
		     (str(qry.report_time) <= str(end.timestamp())))
"""

def compare(start_date, end_date, item):
    if not isinstance(item, int):
        item = time.mktime(timestring.Date(item).date.timetuple())
    return start_date <= item and item <= end_date

def find_string(item):
    if not isinstance(item, int):
        return True

def myop():
    def transform(doc):
        doc['report_time'] = int(time.mktime(timestring.Date(doc['report_time']).date.timetuple()))
    return transform

compare_function = partial(compare, start.timestamp(), end.timestamp())

result = tbl.update(myop(), qry.report_time.test(find_string))

print("Done")
